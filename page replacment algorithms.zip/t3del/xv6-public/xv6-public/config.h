#define selection 0
#define number_of_pgFLTS